
%User chooses which organ to look at here
chooseOrgCha=3;
organVec=["nucleus","presynaptic","postsynaptic","extra"];
%which channel is associated with each organ
channelVec=[1,3,2,4];
channel=channelVec(chooseOrgCha);
organ=organVec(chooseOrgCha);

%Load in some data from the file that I emailed you with some results
nucData=saveInOrigForm{2, 1};
voxNucData=nucData(:,1:3)./resizedVoxel;
preStruct=saveInOrigForm{2, 2};
postStruct=saveInOrigForm{2, 3};

%data for labelvolshow
opacity=.2;
threshold=.01;

%load in data from a different file that I emailed you
[voxel,dimensions,minMax,allData]=initialize('6.czi',1,2,3,4);

%resize image for speed
imageSize=500;
[resizedAllData,resizedDimensions,resizedVoxel]=resizeImage(allData,dimensions,voxel,imageSize,imageSize);


%create two panels
f2=figure;
panVolShow=uipanel(f2,'Position',[0,0,.66,1]);
panOrtho=uipanel(f2,'Position',[.66,0,.33,1]);

%get overlay data for use in labelvolshow. save it as userdata so that it
%can be updated
[finalArr,pixLoc]=getOverlay(voxNucData,preStruct,postStruct,organ,imageSize,resizedVoxel,resizedDimensions,dimensions);
f2.UserData=pixLoc;


%Create labelvolshow and orthosliceviewer objects
volshowView=labelvolshow(uint8(finalArr),resizedAllData(:,:,:,channel),'Parent',panVolShow);
orthoView=orthosliceViewer(resizedAllData(:,:,:,channel),'Parent',panOrtho);
volshowView.VolumeThreshold=threshold;
volshowView.VolumeOpacity=opacity;


%add axes to the labelcolshow figure and add lines so user can see the
%camera target.
a=axes(volshowView.Parent);
a.Position=[0,0,1,1];
a.XLim=[0,1];
a.YLim=[0,1];
a.Interactions=[];
l1=line(a,[.5,.5],[0,1]);
l2=line(a,[0,1],[.5,.5]);

%update the camera target to link the labelvolshow and orthosliceviewer
%object. This allows me to move the orthosliceviewer target and have it
%also target the same place on the labelvolshow object
addlistener(f2,'WindowMouseMotion',@(~,~) adjustCamTarg(volshowView,orthoView,resizedDimensions));

%add an organ. Uses a representative size
addOrg=uicontrol(panOrtho,'Style','pushbutton');
addOrg.String={'Add Organ'};
set(addOrg,'Callback',@(~,~) addOrgan(f2,orthoView,chooseOrgCha,volshowView,imageSize,resizedVoxel,resizedDimensions,dimensions));
addOrg.Position=[10,10,75,25];

%remove nearest organ
removeOrg=uicontrol(panOrtho,'Style','pushbutton');
removeOrg.String={'Remove Organ'};
set(removeOrg,'Callback',@(~,~) removeOrgan(f2,orthoView,chooseOrgCha,volshowView,imageSize,resizedVoxel,resizedDimensions,dimensions));
removeOrg.Position=[85,10,75,25];

%not working yet
% ribSearch=uicontrol(panOrtho,'Style','pushbutton');
% ribSearch.String={'Search for nearby ribbon'};
% set(ribSearch,'Callback',@(~,~) ribbonSearch(f2,orthoView,chooseOrgCha,volshowView,imageSize,resizedVoxel,resizedDimensions,dimensions));
% ribSearch.Position=[160,10,120,25];


%change the camera target to link the orthosliceviewer and labelvolshow
%objects
function adjustCamTarg(volShowView,orthoView,resizedDimensions)
camCalc=((orthoView.SliceNumbers./(resizedDimensions))-.5);
camTarg=[camCalc(1),camCalc(2),camCalc(3)*resizedDimensions(3)/resizedDimensions(1)];
volShowView.CameraTarget=camTarg;

end
%add representative organ
function addOrgan(f2,orthoView,chooseOrgCha,volshowView,imageSize,resizedVoxel,resizedDimensions,dimensions)
f2.UserData=[f2.UserData;orthoView.SliceNumbers];
updateVolume(chooseOrgCha,volshowView,f2.UserData,f2.UserData,f2.UserData,imageSize,resizedVoxel,resizedDimensions,dimensions)
end
%remove nearest organ to the crosshair
function removeOrgan(f2,orthoView,chooseOrgCha,volshowView,imageSize,resizedVoxel,resizedDimensions,dimensions)
ind=dsearchn(f2.UserData,orthoView.SliceNumbers);
f2.UserData(ind,:)=[];
updateVolume(chooseOrgCha,volshowView,f2.UserData,f2.UserData,f2.UserData,imageSize,resizedVoxel,resizedDimensions,dimensions)
end
% function ribbonSearch(f2,orthoView,chooseOrgCha,volshowView,reseizedAlldata,searchRange,imageSize,resizedVoxel,resizedDimensions,dimensions)
% 
% 
% 
% f2.UserData=[f2.UserData;loc];
% updateVolume(chooseOrgCha,volshowView,f2.UserData,f2.UserData,f2.UserData,imageSize,resizedVoxel,resizedDimensions,dimensions);
% end
%

%update the volume so that new organs can be added and viewed
function updateVolume(chooseOrgCha,volshowView,voxNucData,preStruct,postStruct,imageSize,resizedVoxel,resizedDimensions,dimensions)
organVec=["nucleus","presynaptic","postsynaptic","extra"];


organ=(organVec(chooseOrgCha));
[finalArr]=getOverlay(voxNucData,preStruct,postStruct,organ,imageSize,resizedVoxel,resizedDimensions,dimensions);
setVolume(volshowView,uint8(finalArr));

end
